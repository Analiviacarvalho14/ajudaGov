package projeto.ajudagov.dto;


import lombok.*;

@Getter
public class InstituicaoDTO {
    private String email;
    private String senha;
    private String nome;
}
