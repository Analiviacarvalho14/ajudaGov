package projeto.ajudagov.dto;

import lombok.*;

@Getter
public class UsuarioDTO {
    private String email;
    private String senha;
    private String nome;
}
