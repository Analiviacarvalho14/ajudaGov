package projeto.ajudagov.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import projeto.ajudagov.entity.CarteiraDigital;

public interface CarteiraDigitalRepository extends JpaRepository<CarteiraDigital,Long>
{
}
