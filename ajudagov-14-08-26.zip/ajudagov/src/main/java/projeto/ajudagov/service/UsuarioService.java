package projeto.ajudagov.service;

import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;
import projeto.ajudagov.entity.Usuario;
import projeto.ajudagov.repository.UsuarioRepository;

import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    public Optional<Usuario> findByEmail(String email){
        return this.usuarioRepository.findByEmail(email);
    }

    @Transactional
    public void adicionar(Usuario usuario){
        this.usuarioRepository.save(usuario);
    }

    public List<Usuario> listar(){
        return (List<Usuario>) this.usuarioRepository.findAll();
    }

    @Transactional
    public void atualizar(Long id, Usuario usuario){
        Usuario UsuarioAtualizado = this.usuarioRepository.findById(id).orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
        UsuarioAtualizado.setNome(usuario.getNome());
        UsuarioAtualizado.setEmail(usuario.getEmail());
        UsuarioAtualizado.setSenha(usuario.getSenha());
        UsuarioAtualizado.setTelefone(usuario.getTelefone());

    }

    @Transactional
    public void remover(Long id){
        Usuario UsuarioExistente = this.usuarioRepository.findById(id).orElseThrow(() -> new RuntimeException("Usuário não encontrado."));
        this.usuarioRepository.deleteById(id);
    }
}

