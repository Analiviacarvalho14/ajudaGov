package projeto.ajudagov.service;

import jakarta.transaction.Transactional;

import org.springframework.stereotype.Service;
import projeto.ajudagov.entity.CarteiraDigital;
import projeto.ajudagov.repository.CarteiraDigitalRepository;

import java.util.List;

@Service
public class CarteiraDigitalService {

    private final CarteiraDigitalRepository carteiraDigitalRepository;

    public CarteiraDigitalService(CarteiraDigitalRepository carteiraDigitalRepository) {
        this.carteiraDigitalRepository = carteiraDigitalRepository;
    }

    @Transactional
    public void adicionar(CarteiraDigital carteiraDigital){
        this.carteiraDigitalRepository.save(carteiraDigital);
    }

    public List<CarteiraDigital> listar(){
        return (List<CarteiraDigital>) this.carteiraDigitalRepository.findAll();
    }

    @Transactional
    public void remover(Long id){
        CarteiraDigital CarteiraDigitalExistente = this.carteiraDigitalRepository.findById(id).orElseThrow(() -> new RuntimeException("Carteira digital não encontrado"));
        this.carteiraDigitalRepository.deleteById(id);
    }
}

