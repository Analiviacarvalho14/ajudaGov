package projeto.ajudagov.service;

import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;
import projeto.ajudagov.entity.Instituicao;
import projeto.ajudagov.entity.Usuario;
import projeto.ajudagov.repository.InstituicaoRepository;

import java.util.List;
import java.util.Optional;

@Service
public class InstituicaoService {

    private final InstituicaoRepository instituicaoRepository;

    public InstituicaoService(InstituicaoRepository instituicaoRepository) {
        this.instituicaoRepository = instituicaoRepository;
    }

    public Optional<Instituicao> findByEmail(String email){
        return this.instituicaoRepository.findByEmail(email);
    }

    @Transactional
    public void adicionar(Instituicao instituicao){
        this.instituicaoRepository.save(instituicao);
    }

    public List<Instituicao> listar(){
        return (List<Instituicao>) this.instituicaoRepository.findAll();
    }

    @Transactional
    public void atualizar(Long id, Instituicao instituicao){
        Instituicao InstituicaoAtualizado = this.instituicaoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Instituicão não encontrado"));
        InstituicaoAtualizado.setCnpj(instituicao.getCnpj());
        InstituicaoAtualizado.setNome(instituicao.getNome());
        InstituicaoAtualizado.setEmail(instituicao.getEmail());
        InstituicaoAtualizado.setTelefone(instituicao.getTelefone());

    }

    @Transactional
    public void remover(Long id){
        Instituicao InstituicaoExistente = this.instituicaoRepository.findById(id).orElseThrow(() -> new RuntimeException("Instituicão não encontrado"));
        this.instituicaoRepository.deleteById(id);
    }
}

