package projeto.ajudagov.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import projeto.ajudagov.entity.CarteiraDigital;
import projeto.ajudagov.service.CarteiraDigitalService;

import java.util.List;

@RestController
@RequestMapping("/carteiraDigital")
@CrossOrigin(origins = "*")
public class CarteiraDigitalController {

    private final CarteiraDigitalService carteiraDigitalService;

    public CarteiraDigitalController(CarteiraDigitalService carteiraDigitalService) {
        this.carteiraDigitalService = carteiraDigitalService;
    }

    @PostMapping
    public ResponseEntity<CarteiraDigital> adicionar(@RequestBody CarteiraDigital carteiraDigital) {
        carteiraDigitalService.adicionar(carteiraDigital);
        return ResponseEntity.ok(carteiraDigital);
    }

    @GetMapping
    public List<CarteiraDigital> listar(){
        return this.carteiraDigitalService.listar();
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<String> remover(@PathVariable Long id) {
        this.carteiraDigitalService.remover(id);
        return ResponseEntity.ok("Carteira digital removida com sucesso!");
    }
}
