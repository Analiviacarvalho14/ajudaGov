package projeto.ajudagov.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import projeto.ajudagov.dto.InstituicaoDTO;
import projeto.ajudagov.entity.Instituicao;
import projeto.ajudagov.entity.Usuario;
import projeto.ajudagov.service.InstituicaoService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/instituicao")
@CrossOrigin(origins = "*")
public class InstituicaoController {

    private final InstituicaoService instituicaoService;

    public InstituicaoController(InstituicaoService instituicaoService) {
        this.instituicaoService = instituicaoService;
    }

    @RequestMapping("/login")
    public ResponseEntity<String> login(@RequestBody InstituicaoDTO instituicaoDto, HttpSession session) {
        Optional<Instituicao> instituicaoTmp = this.instituicaoService.findByEmail(instituicaoDto.getEmail());

        if (instituicaoTmp.isPresent()) {
            session.setAttribute("instituicao", instituicaoTmp);

            if (instituicaoDto.getSenha().equals(instituicaoTmp.get().getSenha())) {
                return ResponseEntity.ok("Login efetuado com sucesso. Seja bem-vind@ " + instituicaoTmp.get().getNome());
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("A senha está incorreta!");
            }
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Instituição não encontrada.");
        }
    }

    @PostMapping
    public ResponseEntity<Instituicao> adicionar(@RequestBody Instituicao instituicao) {
        instituicaoService.adicionar(instituicao);
        return ResponseEntity.ok(instituicao);
    }

    @GetMapping
    public List<Instituicao> listar(){
        return this.instituicaoService.listar();
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> atualizar(@PathVariable Long id, @RequestBody Instituicao instituicao) {
        this.instituicaoService.atualizar(id, instituicao);
        return ResponseEntity.ok("Instituicão atualizada com sucesso!");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> remover(@PathVariable Long id) {
        this.instituicaoService.remover(id);
        return ResponseEntity.ok("Instituição removida com sucesso!");
    }
}
