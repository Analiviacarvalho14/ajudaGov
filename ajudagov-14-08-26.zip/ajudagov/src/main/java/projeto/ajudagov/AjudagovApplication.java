package projeto.ajudagov;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AjudagovApplication {

	public static void main(String[] args) {
		SpringApplication.run(AjudagovApplication.class, args);
	}

}
