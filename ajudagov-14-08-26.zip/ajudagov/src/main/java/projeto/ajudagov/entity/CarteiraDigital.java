package projeto.ajudagov.entity;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "carteiraDigital")

public class CarteiraDigital {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "usuario_cpf", referencedColumnName = "cpf", foreignKey=@ForeignKey(name = "Fk_usuario_cpf_carteira"))
    private Usuario usuario;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "contaBancaria_id", referencedColumnName = "id", foreignKey=@ForeignKey(name = "Fk_contaBancaria_id_carteira"))
    private ContaBancaria contaBancaria;

}

