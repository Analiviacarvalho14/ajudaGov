package projeto.ajudagov;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AjudagovApplicationTests {

	@Test
	void contextLoads() {
	}

}
