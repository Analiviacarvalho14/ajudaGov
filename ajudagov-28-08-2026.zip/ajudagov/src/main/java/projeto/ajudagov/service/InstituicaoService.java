package projeto.ajudagov.service;

import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;
import projeto.ajudagov.entity.Instituicao;
import projeto.ajudagov.repository.InstituicaoRepository;

import java.util.List;
import java.util.Optional;

import static projeto.ajudagov.service.UsuarioService.sha256;

@Service
public class InstituicaoService {

    private final InstituicaoRepository instituicaoRepository;

    public InstituicaoService(InstituicaoRepository instituicaoRepository) {
        this.instituicaoRepository = instituicaoRepository;
    }

    public Optional<Instituicao> findByEmail(String email){
        return this.instituicaoRepository.findByEmail(email);
    }

    @Transactional
    public void adicionar(Instituicao instituicao) throws Exception {
        instituicao.setSenha(sha256(instituicao.getSenha()));
        this.instituicaoRepository.save(instituicao);
    }

    public List<Instituicao> listar(){
        return this.instituicaoRepository.findAll();
    }

    @Transactional
    public void atualizar(Long id, Instituicao instituicao){
        Instituicao InstituicaoAtualizado = this.instituicaoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Instituicão não encontrado"));
        InstituicaoAtualizado.setCnpj(instituicao.getCnpj());
        InstituicaoAtualizado.setNome(instituicao.getNome());
        InstituicaoAtualizado.setEmail(instituicao.getEmail());
        InstituicaoAtualizado.setTelefone(instituicao.getTelefone());

    }

    @Transactional
    public void remover(Long id){
        this.instituicaoRepository.findById(id).orElseThrow(() -> new RuntimeException("Instituicão não encontrado"));
        this.instituicaoRepository.deleteById(id);
    }
}

