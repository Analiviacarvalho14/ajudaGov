

async function carregarImagemImgBB() {
    try {
        const response = await fetch(`instituicao`);
    if (!response.ok) {
        throw new Error(`Erro ao carregar o JSON: ${response.statusText}.`);
    }

    const dados = await response.json();

    } catch (erro) {
        console.error('Erro ao carregar as iamgens:', erro)
    }
    
}


function renderizarCardsOng(instituicoes, container) {
    if (instituicoes.length === 0) {
        container.innerHTML = '<p class="sem-resultados">Nenhuma ONG cadastrada ainda.</p>';
        return;
    }

    // data-cnpj é usado pelo clique (ver ativarCliqueParaRelatorio) para
    // saber para qual relatorioOng.html?cnpj=... levar o usuário.
    container.innerHTML = instituicoes.map(ong => `
        <div class="card-ong" data-cnpj="${escaparHtml(ong.cnpj)}">
            <div class="card-header">
                <img class="card-ong-foto" src="${escaparHtml(ong.imagem)}" alt="Foto de ${escaparHtml(ong.nome)}">
                ${escaparHtml(ong.nome)}
            </div>
            <p class="card-desc">${escaparHtml(ong.descricao) || 'Esta ONG ainda não cadastrou uma descrição.'}</p>
        </div>
    `).join('');
}


function renderizarCardsUrgentes(instituicoes, container) {
    const urgentes = instituicoes.filter(ehProjetoUrgente).slice(0, 3);

    if (urgentes.length === 0) {
        container.innerHTML = '<p class="sem-resultados">Nenhum projeto urgente no momento.</p>';
        return;
    }

    container.innerHTML = urgentes.map(ong => `
        <div class="card-urgente ${(ong.urgencia || '').toLowerCase()}" data-cnpj="${escaparHtml(ong.cnpj)}">
            <img src="${escaparHtml(ong.imagem)}" width="64" height="64" alt="Foto de ${escaparHtml(ong.nome)}">
            <div class="info-principal">
                <strong>${escaparHtml(ong.nome)}</strong>
                <span>${escaparHtml(ong.descricao) || 'Sem descrição cadastrada.'}</span>
            </div>
            <div class="info-necessidades">
                <strong>NECESSIDADES:</strong>
                <span>${escaparHtml(ong.necessidades) || 'Não informado'}</span>
            </div>
        </div>
    `).join('');
}

// Um único listener por container (delegação de evento) em vez de um
// onclick por card — funciona mesmo depois que renderizarCardsOng/
// renderizarCardsUrgentes trocam o innerHTML de novo.
function ativarCliqueParaRelatorio(container) {
    if (!container) return;

    container.addEventListener('click', (evento) => {
        const card = evento.target.closest('.card-ong, .card-urgente');
        if (!card) return;

        const cnpj = card.getAttribute('data-cnpj');
        if (!cnpj) return;

        window.location.href = `relatorioOng.html?cnpj=${encodeURIComponent(cnpj)}`;
    });
}

// Inicialização das visualizações
document.addEventListener('DOMContentLoaded', async () => {
    const gridOngs = document.getElementById('grid-ongs');
    const listaUrgentes = document.getElementById('lista-urgentes');
    
    if (!gridOngs && !listaUrgentes) return;

    const instituicoes = await buscarInstituicoes();

    if (gridOngs) {
        renderizarCardsOng(instituicoes, gridOngs);
        ativarCliqueParaRelatorio(gridOngs);
    }
    if (listaUrgentes) {
        renderizarCardsUrgentes(instituicoes, listaUrgentes);
        ativarCliqueParaRelatorio(listaUrgentes);
    }
});