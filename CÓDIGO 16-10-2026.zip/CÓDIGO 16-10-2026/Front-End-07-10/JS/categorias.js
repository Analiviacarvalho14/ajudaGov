/**
 * categorias.js — usado SOMENTE por categorias.html
 * (a página de Regiões agora tem o seu próprio arquivo: regioes.js)
 *
 * Filtra os cards de ONGs pelo campo "atuacao" (saude, crianca, idoso, animal).
 */
(function () {
    const TEXTO_ATUACAO = {
        saude: 'Saúde',
        crianca: 'Crianças',
        idoso: 'Idosos',
        animal: 'Animais',
        outra: 'Outra'
    };

    // Filtros marcados no momento (seleção múltipla). Vazio = "Todos".
    const filtrosAtivos = new Set();

    document.addEventListener('DOMContentLoaded', async () => {
        const container = document.getElementById('lista-ongs');
        if (!container) return;

        const instituicoes = await buscarInstituicoes();
        renderizarCartoes(instituicoes, container);
        ativarFiltro();
        ativarBusca();
        aplicarFiltroDaUrl();
    });

    // Padroniza o valor salvo no banco: "Saúde " -> "saude"
    function normalizar(valor) {
        return (valor || '')
            .toString()
            .trim()
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '');
    }

    function renderizarCartoes(instituicoes, container) {
        if (instituicoes.length === 0) {
            container.innerHTML = '<p class="sem-resultados">Nenhuma ONG cadastrada ainda.</p>';
            return;
        }

        container.innerHTML = instituicoes.map(ong => {
            const atuacao = normalizar(ong.atuacao);
            const classeUrgencia = (ong.urgencia || '').toLowerCase();
            const imagem = ong.imagem && ong.imagem.trim() !== '' ? ong.imagem : FOTO_PADRAO_ONG;

            return `
                <a href="relatorioOng.html?cnpj=${encodeURIComponent(ong.cnpj)}" class="cartao-ong ${classeUrgencia}" data-categoria="${escaparHtml(atuacao)}">
                    <img src="${escaparHtml(imagem)}" width="64" height="64" alt="Foto de ${escaparHtml(ong.nome)}">
                    <div class="informacoes-principais">
                        <strong>${escaparHtml(ong.nome)}</strong>
                        <span>Atuação: ${escaparHtml(TEXTO_ATUACAO[atuacao] || ong.atuacao) || 'Não informado'}</span>
                    </div>
                    <div class="informacoes-extras">
                        <strong>NECESSIDADE:</strong>
                        <span>${escaparHtml(ong.necessidades) || 'Nenhuma necessidade cadastrada'}</span>
                    </div>
                </a>
            `;
        }).join('');
    }

    function ativarFiltro() {
        const botoes = document.querySelectorAll('.botao-categoria[data-filtro]');
        const botaoLimpar = document.querySelector('.botao-limpar');

        botoes.forEach(botao => {
            botao.addEventListener('click', () => {
                const filtro = botao.getAttribute('data-filtro');

                if (filtro === 'todos') {
                    filtrosAtivos.clear();
                } else if (filtrosAtivos.has(filtro)) {
                    filtrosAtivos.delete(filtro);
                } else {
                    filtrosAtivos.add(filtro);
                }

                atualizarBotoesAtivos(botoes);
                aplicarFiltros();
            });
        });

        if (botaoLimpar) {
            botaoLimpar.addEventListener('click', () => {
                filtrosAtivos.clear();
                const inputBusca = document.getElementById('input-busca');
                if (inputBusca) inputBusca.value = '';
                atualizarBotoesAtivos(botoes);
                aplicarFiltros();
            });
        }
    }

    // "Todos" fica marcado quando nenhuma categoria específica está selecionada.
    function atualizarBotoesAtivos(botoes) {
        botoes.forEach(botao => {
            const filtro = botao.getAttribute('data-filtro');
            const ativo = filtro === 'todos' ? filtrosAtivos.size === 0 : filtrosAtivos.has(filtro);
            botao.classList.toggle('ativo', ativo);
        });
    }

    // Filtro de botões + busca por texto juntos
    function aplicarFiltros() {
        const inputBusca = document.getElementById('input-busca');
        const termoBusca = inputBusca ? inputBusca.value.toLowerCase() : '';

        document.querySelectorAll('.cartao-ong').forEach(cartao => {
            const atuacaoCartao = cartao.getAttribute('data-categoria');
            const passaNoFiltro = filtrosAtivos.size === 0 || filtrosAtivos.has(atuacaoCartao);
            const passaNaBusca = !termoBusca || cartao.textContent.toLowerCase().includes(termoBusca);
            cartao.classList.toggle('escondido', !(passaNoFiltro && passaNaBusca));
        });
    }

    function ativarBusca() {
        const inputBusca = document.getElementById('input-busca');
        if (inputBusca) inputBusca.addEventListener('input', aplicarFiltros);
    }

    // Lê ?categoria=... (paginaEntrada.html) ou ?cat=... (buscas.js) da URL
    function aplicarFiltroDaUrl() {
        const params = new URLSearchParams(window.location.search);
        const valor = normalizar(params.get('categoria') || params.get('cat'));
        if (!valor) return;

        const botao = document.querySelector(`.botao-categoria[data-filtro="${valor}"]`);
        if (botao) botao.click();
    }
})();
